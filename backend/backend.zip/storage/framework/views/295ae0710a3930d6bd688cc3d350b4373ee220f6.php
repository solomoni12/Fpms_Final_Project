<?php echo e($slot); ?>

<?php /**PATH D:\Final year project\FINAL_PROJECT\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>